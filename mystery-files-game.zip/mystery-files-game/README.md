# Mystery Files

A playable browser-game prototype with a soft pastel palette, dark mystery atmosphere, character selection, suspect conversations, clue collection, a detective journal, keyboard/touch movement, and a 1,000-case progression system.

## Run locally
Open `index.html` in a browser. No build step or dependencies are required.

## Deploy to GitHub + Vercel
1. Create a new GitHub repository called `mystery-files`.
2. Upload `index.html`, `styles.css`, `game.js`, and `vercel.json` to the repository root.
3. In Vercel, choose **Add New → Project**, import the GitHub repository, and deploy.
4. Use the default settings. This is a static website, so no build command is needed.

## Controls
- **Computer:** WASD or arrow keys to move. Click suspects and glowing clues.
- **iPad/iPhone:** use the on-screen arrow pad; tap characters and clues.
- **Case files:** view unlocked levels and revisit any unlocked case.
- **Journal:** review collected evidence.

## Notes
This is a front-end prototype. The 1,000 cases are generated from reusable templates and increasing difficulty rules, rather than 1,000 individually authored stories. Progress is held in memory and resets when the page reloads. A future version can add saved progress, richer 3D scenes, deeper branching dialogue, and a backend.

## Project structure
- `index.html` — interface and game scene
- `styles.css` — responsive visual design
- `game.js` — movement, characters, clues, interrogation, progression
- `vercel.json` — static deployment configuration
