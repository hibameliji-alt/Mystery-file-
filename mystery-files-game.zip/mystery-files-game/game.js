(() => {
  const $ = id => document.getElementById(id);
  const characterData = [
    {id:'player',name:'You',role:'Detective',skin:'#f0c8ac',hair:'#4a334a',coat:'#c7b8ff',x:50,y:77,player:true},
    {id:'mira',name:'Mira Vale',role:'The Heir',skin:'#d99f83',hair:'#30283d',coat:'#f2c6e8',x:28,y:66,secret:'I was in the conservatory. I heard a glass break just before the clock chimed.',truth:'The conservatory window was already cracked before the storm.',tell:'She keeps glancing at the broken window.',color:'#f2c6e8'},
    {id:'theo',name:'Theo Finch',role:'The Groundskeeper',skin:'#f1c6a6',hair:'#654634',coat:'#b8f1df',x:72,y:69,secret:'I locked the garden gate at eleven. Someone had walked through the wet flowerbed afterward.',truth:'The muddy footprints are too small to be his boots.',tell:'Mud is dried on his sleeve, but the footprints are smaller.',color:'#b8f1df'},
    {id:'iris',name:'Iris Wren',role:'The Pianist',skin:'#e8bba1',hair:'#a7a0bd',coat:'#c4d4f4',x:60,y:53,secret:'I was playing in the music room. The piano stopped when the lights flickered.',truth:'The music room clock was ten minutes slow.',tell:'Her story depends on a clock that never kept the right time.',color:'#c4d4f4'}
  ];
  const avatarLooks = [
    {name:'Nova',skin:'#f0c8ac',hair:'#4a334a',coat:'#c7b8ff'},
    {name:'Rory',skin:'#a96f55',hair:'#2a2637',coat:'#b8f1df'},
    {name:'Sage',skin:'#e9c6a3',hair:'#8b5c55',coat:'#f2c6e8'},
    {name:'Ash',skin:'#d6a78d',hair:'#30364b',coat:'#c4d4f4'}
  ];
  const clueTemplates = [
    {name:'A cracked window',detail:'Fresh glass dust clings to the sill. The break came from inside the conservatory.',icon:'◇',x:19,y:53},
    {name:'Muddy footprints',detail:'Small muddy prints lead away from the conservatory, not toward it.',icon:'⌁',x:81,y:80},
    {name:'A stopped pocket watch',detail:'The watch stopped at 11:17, but the storm knocked the manor clock out of sync.',icon:'◷',x:47,y:85},
    {name:'A silver thread',detail:'A pale silver thread is caught on the display case. Someone brushed past it.',icon:'✧',x:69,y:43},
    {name:'A torn note',detail:'The note says: “The east door will be open.” The handwriting is hurried.',icon:'▤',x:37,y:48},
    {name:'A wet glove',detail:'A wet glove was hidden under the stairs. It smells faintly of roses.',icon:'♧',x:88,y:58}
  ];
  const caseNames = ['The Vanishing Moonstone','The Clockmaker’s Secret','A Portrait in the Rain','The Last Train at Midnight','The Lighthouse Cipher','The Velvet Room','The Silent Bell','The Orchid Alibi','A Letter Never Sent','The Glass Garden'];
  const descriptions = [
    'A priceless moonstone disappeared during a storm. Everyone claims they were somewhere else. Find the clues and uncover the lie.',
    'A clock stopped at the exact moment a rare key vanished. Three people insist they never entered the workshop.',
    'A portrait has been switched with a convincing copy. Someone knows the gallery better than they admit.',
    'A passenger disappeared between two stations. The timetable holds one detail nobody noticed.',
    'The lighthouse lamp went dark, and a coded message was left behind. The keeper says it means nothing.'
  ];
  let level = 1, xp = 0, selectedAvatar = 0, found = new Set(), questioned = new Set(), unlocked = 1, solved = false, activeSuspect = null;
  let player = {x:50,y:77};
  let cluesForCase = [];
  const allCharacters = characterData.map(c=>({...c}));
  const suspectIds = ['mira','theo','iris'];
  const clamp = (n,min,max)=>Math.max(min,Math.min(max,n));
  const caseName = n => caseNames[(n-1)%caseNames.length];
  const difficulty = n => n<5?'EASY':n<25?'MEDIUM':n<100?'HARD':n<400?'EXPERT':'LEGENDARY';
  const caseDescription = n => n<5?descriptions[(n-1)%descriptions.length]:`Case ${String(n).padStart(3,'0')} has ${Math.min(6,3+Math.floor(n/80))} evidence points and ${Math.min(5,2+Math.floor(n/100))} people of interest. Read between the lines: the truth gets less obvious every time.`;
  function renderCharacters(){
    const root=$('characters'); root.innerHTML='';
    allCharacters.forEach(c=>{
      const pos=c.player?player:c;
      const button=document.createElement('button');
      button.className='character'+(c.player?' player':''); button.style.left=pos.x+'%';button.style.top=pos.y+'%';
      button.style.setProperty('--skin',c.skin);button.style.setProperty('--hair',c.hair);button.style.setProperty('--coat',c.coat);
      button.setAttribute('aria-label',c.player?'Your character':`Talk to ${c.name}`);
      button.innerHTML=`<span class="person"><span class="hair"></span><span class="head"></span><span class="body"></span></span><span class="character-name">${c.name}</span>${c.player?'':'<span class="role-dot">?</span>'}`;
      if(!c.player) button.addEventListener('click',()=>openInterrogation(c.id));
      root.appendChild(button);
    });
  }
  function createClues(){
    const count=Math.min(6,3+Math.floor((level-1)/80));
    const shuffled=[...clueTemplates].sort((a,b)=>((a.x*level+a.y*3)%17)-((b.x*level+b.y*3)%17));
    cluesForCase=shuffled.slice(0,count).map((c,i)=>({...c,key:`${level}-${i}`,found:false,
      x:clamp(c.x+(((level+i)%5)-2)*2,10,90),y:clamp(c.y+(((level*3+i)%5)-2)*2,39,85)}));
    found=new Set();questioned=new Set();solved=false;
    $('clues').innerHTML='';
    cluesForCase.forEach(c=>{
      const b=document.createElement('button');b.className='clue';b.style.left=c.x+'%';b.style.top=c.y+'%';b.textContent=c.icon;b.title=c.name;
      b.setAttribute('aria-label',`Collect clue: ${c.name}`);
      b.addEventListener('click',()=>collectClue(c,b));$('clues').appendChild(b);
    });
    renderCharacters();updateUI();
  }
  function collectClue(c,button){
    if(c.found){toast('You already logged this clue.');return}
    c.found=true;found.add(c.key);button.classList.add('found');button.textContent='✓';xp+=10;
    toast(`Clue found: ${c.name}`);updateUI();
  }
  function move(dx,dy){
    if($('dialogBackdrop').classList.contains('hidden')===false)return;
    player.x=clamp(player.x+dx,6,94);player.y=clamp(player.y+dy,43,88);renderCharacters();
    const nearby=cluesForCase.find(c=>!c.found&&Math.hypot(c.x-player.x,c.y-player.y)<6);
    if(nearby) toast(`Near a clue: ${nearby.name}. Tap the glowing symbol.`);
  }
  function openInterrogation(id){
    const c=allCharacters.find(x=>x.id===id);if(!c)return;activeSuspect=c;
    $('dialogBackdrop').classList.remove('hidden');$('dialogEyebrow').textContent='INTERROGATION ROOM';
    $('dialogTitle').textContent=c.name;$('dialogText').textContent=`${c.role}. They seem willing to talk, but will they tell the whole truth?`;
    const options=[
      {label:'“Where were you when the moonstone vanished?”',answer:c.secret},
      {label:'“What did you notice that night?”',answer:c.truth},
      {label:'“Is there anything you are leaving out?”',answer:c.tell}
    ];
    const box=$('dialogOptions');box.innerHTML='';
    options.forEach((o,i)=>{const b=document.createElement('button');b.className='question-option';b.innerHTML=`${o.label}<span>↗</span>`;b.addEventListener('click',()=>{
      $('dialogText').textContent=`${c.name}: “${o.answer}”`;
      questioned.add(c.id);xp+=5;updateUI();
      box.innerHTML='';
      const follow=document.createElement('button');follow.className='question-option';follow.innerHTML='Ask another question <span>↗</span>';follow.onclick=()=>openInterrogation(c.id);box.appendChild(follow);
      const close=document.createElement('button');close.className='question-option';close.innerHTML='Return to the manor <span>×</span>';close.onclick=closeDialog;box.appendChild(close);
    });box.appendChild(b)});
  }
  function closeDialog(){$('dialogBackdrop').classList.add('hidden')}
  function updateUI(){
    $('caseNumber').textContent=String(level).padStart(3,'0');$('xp').textContent=xp;
    $('levelProgress').textContent=`${unlocked} / 1000`;$('caseTitle').textContent=caseName(level);
    $('caseDescription').textContent=caseDescription(level);$('difficulty').textContent=difficulty(level);
    $('difficulty').className='difficulty '+(level<5?'':level<25?'medium':'hard');
    $('playerName').textContent=avatarLooks[selectedAvatar].name;
    $('clueCount').textContent=`${found.size}/${cluesForCase.length}`;
    const targetClues=Math.min(3,cluesForCase.length),targetQuestions=Math.min(2,Math.max(1,Math.floor((level+1)/50)+1));
    const p=Math.min(100,Math.round((Math.min(found.size,targetClues)/targetClues*.65+Math.min(questioned.size,targetQuestions)/targetQuestions*.35)*100));
    $('progressText').textContent=p+'%';$('progressBar').style.width=p+'%';
    $('objectiveText').textContent=`Find ${targetClues} clues and question ${targetQuestions} suspect${targetQuestions===1?'':'s'}.`;
    const ready=found.size>=targetClues&&questioned.size>=targetQuestions;
    $('solveButton').disabled=!ready||solved;$('nextCaseButton').disabled=!solved||level>=1000;
    $('solveButton').textContent=solved?'Case solved!':ready?'Accuse the culprit':'Gather evidence first';
    $('solveButton').innerHTML=`${solved?'Case solved!':ready?'Accuse the culprit':'Gather evidence first'} <span>↗</span>`;
  }
  function accuse(){
    if(solved)return;
    const required=Math.min(3,cluesForCase.length),questions=Math.min(2,Math.max(1,Math.floor((level+1)/50)+1));
    if(found.size<required||questioned.size<questions){toast('Find more clues and question suspects first.');return}
    $('dialogBackdrop').classList.remove('hidden');$('dialogEyebrow').textContent='MAKE YOUR DEDUCTION';
    $('dialogTitle').textContent='Who is hiding something?';$('dialogText').textContent='Review the evidence, then choose who you think is responsible. This first prototype uses a generated case logic, so follow the clues and trust your detective instincts.';
    const box=$('dialogOptions');box.innerHTML='';
    const culprit=suspectIds[(level*7+found.size+questioned.size)%suspectIds.length];
    allCharacters.filter(c=>!c.player).forEach(c=>{
      const b=document.createElement('button');b.className='question-option';b.innerHTML=`${c.name} <span>↗</span>`;
      b.onclick=()=>{
        if(c.id===culprit){solved=true;xp+=50;unlocked=Math.max(unlocked,Math.min(1000,level+1));$('dialogEyebrow').textContent='CASE CLOSED';$('dialogTitle').textContent='The truth comes to light.';$('dialogText').textContent=`Correct deduction. Case ${String(level).padStart(3,'0')} is closed. You earned 50 XP. The next file is waiting in the archive.`;box.innerHTML='';const next=document.createElement('button');next.className='question-option';next.innerHTML='Open next case <span>→</span>';next.onclick=()=>{closeDialog();if(level<1000){level++;player={x:50,y:77};createClues()}};box.appendChild(next);updateUI();}
        else{$('dialogText').textContent=`Not quite. ${c.name}'s story doesn't fit all the evidence. Revisit the clues and question the others before you decide.`;xp+=2;updateUI()}
      };box.appendChild(b);
    });
  }
  function toast(message){const t=$('toast');t.textContent=message;t.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.classList.remove('show'),1900)}
  function openJournal(){
    $('journalBackdrop').classList.remove('hidden');const list=$('journalList');list.innerHTML='';
    const collected=cluesForCase.filter(c=>c.found);
    if(!collected.length)list.innerHTML='<p class="dialog-text">No evidence yet. Look for glowing symbols around the manor.</p>';
    collected.forEach(c=>{const item=document.createElement('div');item.className='journal-item';item.innerHTML=`<span class="evidence-icon">${c.icon}</span><div><b>${c.name}</b><span>${c.detail}</span></div>`;list.appendChild(item)});
    if(questioned.size){const item=document.createElement('div');item.className='journal-item';item.innerHTML=`<span class="evidence-icon">✧</span><div><b>People questioned</b><span>${allCharacters.filter(c=>questioned.has(c.id)).map(c=>c.name).join(', ')}</span></div>`;list.appendChild(item)}
  }
  function openLevels(){
    $('levelsBackdrop').classList.remove('hidden');const grid=$('levelsGrid');grid.innerHTML='';
    const start=Math.max(1,Math.min(level-10,unlocked-20));const end=Math.min(1000,Math.max(40,unlocked+20));
    for(let n=start;n<=end;n++){const tile=document.createElement('div');tile.className='level-tile'+(n<=unlocked?' unlocked':'')+(n===level?' current':'');tile.innerHTML=`${String(n).padStart(3,'0')}<span>${n<=unlocked?(n<level?'CLEARED':'OPEN'):'LOCKED'}</span>`;if(n<=unlocked)tile.style.cursor='pointer';tile.onclick=()=>{if(n<=unlocked){level=n;player={x:50,y:77};$('levelsBackdrop').classList.add('hidden');createClues()}};grid.appendChild(tile)}
  }
  $('avatarChoices').innerHTML=avatarLooks.map((a,i)=>`<button class="avatar-choice ${i===0?'active':''}" data-avatar="${i}"><span class="mini-avatar" style="--skin:${a.skin};--coat:${a.coat}"></span>${a.name}</button>`).join('');
  $('avatarChoices').querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>{selectedAvatar=Number(b.dataset.avatar);const look=avatarLooks[selectedAvatar];const p=allCharacters[0];p.skin=look.skin;p.hair=look.hair;p.coat=look.coat;$('avatarChoices').querySelectorAll('button').forEach(x=>x.classList.toggle('active',x===b));renderCharacters();updateUI()}));
  document.querySelectorAll('[data-move]').forEach(b=>b.addEventListener('click',()=>{const d=b.dataset.move;move(d==='left'?-3:d==='right'?3:0,d==='up'?-3:d==='down'?3:0)}));
  window.addEventListener('keydown',e=>{const k=e.key.toLowerCase();const map={arrowup:[0,-2],w:[0,-2],arrowdown:[0,2],s:[0,2],arrowleft:[-2,0],a:[-2,0],arrowright:[2,0],d:[2,0]};if(map[k]){e.preventDefault();move(...map[k])}});
  $('solveButton').addEventListener('click',accuse);$('nextCaseButton').addEventListener('click',()=>{if(solved&&level<1000){level++;player={x:50,y:77};createClues()}});
  $('journalButton').addEventListener('click',openJournal);$('closeJournal').addEventListener('click',()=>$('journalBackdrop').classList.add('hidden'));$('journalDone').addEventListener('click',()=>$('journalBackdrop').classList.add('hidden'));
  $('levelsButton').addEventListener('click',openLevels);$('closeLevels').addEventListener('click',()=>$('levelsBackdrop').classList.add('hidden'));$('closeDialog').addEventListener('click',closeDialog);
  $('dialogBackdrop').addEventListener('click',e=>{if(e.target===$('dialogBackdrop'))closeDialog()});
  $('journalBackdrop').addEventListener('click',e=>{if(e.target===$('journalBackdrop'))$('journalBackdrop').classList.add('hidden')});
  $('levelsBackdrop').addEventListener('click',e=>{if(e.target===$('levelsBackdrop'))$('levelsBackdrop').classList.add('hidden')});
  createClues();
})();